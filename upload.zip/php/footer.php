			
	<style>
	  .footer {
		  position: absolute;
		  bottom: 0;
		  width: auto;
		  height: 60px;
		}
	</style>
			<div class="footer">
				<div class="container">
					<div class="row">
						
						<div class="col-xs-6">
							<!--(c)Copyright 2015 blah blah-->
						</div>
						<div class="col-xs-6">
							<a href="http://www.twitter.com"><img src="../img/twitter.png"></a>
							<a href="http://www.facebook.com"><img src="../img/facebook.png"></a>
							<a href="http://www.youtube.com"><img src="../img/youtube.png"></a>
						</div>
					</div>
				</div>
			</div>